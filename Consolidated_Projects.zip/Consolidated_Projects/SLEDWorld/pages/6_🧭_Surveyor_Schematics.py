st.title("Surveyor Schematics")

surveyor = world.surveyor
st.json(surveyor.snapshot())