# peripheral_nervous_system/efferent.py

class EfferentPathway:
    """
    Carries motor commands from CNS.
    """

    def transmit(self, command):
        return command
