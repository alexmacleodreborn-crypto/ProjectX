# peripheral_nervous_system/afferent.py

class AfferentPathway:
    """
    Carries sensory signals to CNS.
    """

    def transmit(self, signal):
        return signal
