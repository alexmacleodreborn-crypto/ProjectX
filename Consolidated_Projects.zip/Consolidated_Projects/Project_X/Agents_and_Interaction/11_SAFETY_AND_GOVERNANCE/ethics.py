# ethics.py

class EthicsGuard:
    """
    Hard ethical boundaries.
    """

    def evaluate(self, action: dict) -> dict:
        # Placeholder rule set
        return {
            "allowed": True,
            "reason": "No ethical violation detected"
        }
