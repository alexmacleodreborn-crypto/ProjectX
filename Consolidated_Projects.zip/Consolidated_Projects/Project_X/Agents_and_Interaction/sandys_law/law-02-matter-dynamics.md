# Codex Entry — Law 2: Matter Dynamics (LMD)

**Status:** Frozen  \
**Dependency:** Law 1 (Quantum Curvature)  \
**Scope:** Matter stress–energy only  \
**Domain:** Extreme density, strong confinement  \
**Author:** Sandy’s Law Framework

---

## 2.0 Purpose of Law 2

The Law of Matter Dynamics (LMD) exists to answer a single, unavoidable question left open by Law 1:

If spacetime curvature is capped at high values, what prevents matter from piling up infinitely against that cap?

General Relativity does not answer this. Law 1 (Quantum Curvature) regulates geometry, but geometry alone cannot regulate matter.

Law 2 provides the missing half of the stability mechanism.

---

## 2.1 Plain-Language Statement

The Law of Matter Dynamics states:

At sufficiently high density and confinement, ordinary matter develops a vacuum-mediated self-regulating pressure that limits further compression, without introducing exotic matter or new particles.

In simple terms:

- At low and moderate density, matter behaves exactly as standard physics predicts.
- At extreme density, matter feels the stiffness of quantum-corrected spacetime and the vacuum itself.
- This produces a self-limiting response that prevents runaway collapse.

LMD is not a new substance. It is ordinary matter responding differently under extreme conditions.

---

## 2.2 Why Law 2 Is Necessary

Without Law 2:

- Law 1 caps curvature
- Matter continues to fall inward
- Density diverges even though curvature does not
- Predictability breaks again

With Law 2:

- Geometry self-regulates (Law 1)
- Matter self-regulates (Law 2)
- Collapse halts smoothly
- No singularities remain anywhere

Law 2 is not optional. It is logically required once Law 1 is accepted.

---

## 2.3 Core Mathematical Statement

The effective pressure of matter is modified as:

```math
P = P_{\text{std}} - \frac{1}{3}\,\gamma'\,n^{4/3}
```

Where:

- `P_{\text{std}}`: standard matter pressure (nuclear, degenerate, or relativistic as appropriate)
- `n`: number density of matter
- `\gamma' > 0`: vacuum–matter coupling constant

This is the entire law. No additional terms are assumed.

---

## 2.4 Physical Meaning of the LMD Term

### 2.4.1 Why the n^{4/3} scaling?

This scaling is not arbitrary. It arises naturally from:

- Quantum degeneracy limits
- Phase-space confinement
- Vacuum response to compressed matter
- Casimir-like effects in high-density systems

It is the only power law that:

- Activates late enough to preserve normal matter physics
- Activates early enough to prevent collapse

Lower powers act too early. Higher powers act too late.

### 2.4.2 Why the negative sign?

The correction acts as a vacuum tension, not a repulsive force.

Effects:

- Softens matter at intermediate density
- Strongly resists further compression at extreme density
- Prevents infinite pile-up without introducing exotic pressure

This resolves the neutron-star equation-of-state tension:

- Soft enough for tidal deformability
- Stiff enough for \(>2\,M_\odot\) stars

---

## 2.5 Regimes of Validity

| Regime | Density | LMD Effect |
| --- | --- | --- |
| Laboratory | Low | Zero |
| Stars | Moderate | Negligible |
| White dwarfs | High | Tiny |
| Neutron stars | Extreme | Dominant |
| Core collapse | Extreme | Essential |
| Early universe | Extreme | Essential |

LMD does not modify chemistry, atoms, or particle interactions. It is a collective macroscopic effect.

---

## 2.6 Dynamical Interpretation

At extreme density, matter obeys an effective saturation behavior:

```math
\dot n = A n \left[1 - \left(\frac{n}{n_{\text{crit}}}\right)^{1/3}\right]
```

This implies:

- Growth at low density
- Slowing near a critical density
- Asymptotic saturation at `n_{\text{crit}}`

This behavior was explicitly demonstrated in toy simulations.

---

## 2.7 Empirical Anchoring

The parameter `\gamma'` is not free. It is constrained by:

- NICER neutron-star mass–radius data
- GW170817 tidal deformability
- Maximum observed neutron-star masses
- Stability and causality bounds

Allowed magnitude:

```text
\gamma' \sim 10^{-36} \;\text{(SI-scaled)}
```

If:

- `\gamma' \to 0`: matter collapses too easily
- `\gamma'` too large: stars become unphysically rigid

Data selects a narrow viable window.

---

## 2.8 What Law 2 Explains

**Neutron stars**

- Supports heavy neutron stars
- Preserves correct radii
- Matches tidal deformability
- No exotic cores required

**Core collapse**

- Prevents infinite compression
- Enables smooth halting of collapse
- Prepares system for radiation escape

**Early universe matter**

- Prevents pathological matter domination
- Allows smooth transition to curvature-driven expansion

---

## 2.9 What Law 2 Does NOT Claim

LMD does not introduce:

- New particles
- Dark fluids
- Modified Standard Model forces
- Violations of local QFT

It is a vacuum-mediated correction to matter stress–energy under extreme confinement.

---

## 2.10 Toy Simulations (Validated)

The following mechanisms were explicitly demonstrated:

1. Pressure vs density: LMD invisible at low density, active at extreme density
2. Causality & stability: sound speed remains real and subluminal
3. Neutron-star core profiles: smooth pressure gradients, no instabilities
4. Matter saturation dynamics: finite density attractor, no divergence

These tests establish internal consistency.

---

## 2.11 Falsification Criteria

Law 2 is falsified if:

1. Neutron-star observations force `\gamma' \to 0`
2. Sound speed exceeds the speed of light
3. Matter becomes unstable at moderate density
4. Collapse simulations require exotic matter to halt

None of these conditions are currently met.

---

## 2.12 Relationship to Other Laws

- **Law 1 (Quantum Curvature):** regulates geometry
- **Law 2 (Matter Dynamics):** regulates matter within that geometry

Law 2 never modifies Law 1. It completes it.

---

## 2.13 Law 2 Lock

Law 2 — Matter Dynamics is now frozen.

- Assumptions fixed
- Equation fixed
- Parameter constrained
- Simulations validated
- Failure modes explicit

No later law may alter it.

---

## 2.14 Next Logical Step

With:

- Curvature stabilized (Law 1)
- Matter stabilized (Law 2)

The next logical step is a new law that governs system-level evolution in the stabilized regime.
