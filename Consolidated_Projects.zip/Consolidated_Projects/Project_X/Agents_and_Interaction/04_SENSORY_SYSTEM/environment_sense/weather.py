# environment_sense/weather.py

class WeatherSense:
    """
    Detects weather conditions.
    """

    def read(self, conditions):
        return {"weather": conditions}
