# olfaction/chemical_space.py

class ChemicalSpace:
    """
    Represents smell similarity.
    """

    def map(self, smell_vector):
        return {"chemical_space": smell_vector}
