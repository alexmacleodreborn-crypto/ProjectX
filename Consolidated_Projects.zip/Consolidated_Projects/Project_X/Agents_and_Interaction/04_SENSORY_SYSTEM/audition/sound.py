# audition/sound.py

class SoundSense:
    """
    Raw auditory input.
    """

    def capture(self, waveform):
        return {"waveform": waveform}
