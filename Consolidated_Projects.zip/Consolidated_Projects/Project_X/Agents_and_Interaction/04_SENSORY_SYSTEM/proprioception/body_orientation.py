# proprioception/body_orientation.py

class BodyOrientationSense:
    """
    Tracks body orientation.
    """

    def sense(self, orientation):
        return {"orientation": orientation}
