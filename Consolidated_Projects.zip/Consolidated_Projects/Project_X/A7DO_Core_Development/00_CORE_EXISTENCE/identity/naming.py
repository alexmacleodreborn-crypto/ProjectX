# identity/naming.py

class NamingSystem:
    """
    Handles how A7DO refers to itself and others.
    """

    def __init__(self):
        self.self_name = "A7DO"

    def get_self_name(self):
        return self.self_name
