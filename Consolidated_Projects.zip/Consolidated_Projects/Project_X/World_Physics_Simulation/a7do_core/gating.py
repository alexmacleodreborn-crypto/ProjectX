def allow_event(intensity):
    # Sandys Law–style gating
    return intensity < 5.0