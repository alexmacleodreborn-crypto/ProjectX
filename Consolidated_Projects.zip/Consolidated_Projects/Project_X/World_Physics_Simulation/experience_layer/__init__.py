# experience_layer/__init__.py
"""
Pre-symbolic sensory and experiential fields.
"""