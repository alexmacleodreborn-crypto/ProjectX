# environments/nature.py

class NatureEnvironment:
    """
    Environment governed strongly by physics.
    """

    def __init__(self):
        self.conditions = {}
