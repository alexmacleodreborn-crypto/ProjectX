# environments/abstract.py

class AbstractEnvironment:
    """
    Symbolic or conceptual space.
    """

    def __init__(self):
        self.structures = []
