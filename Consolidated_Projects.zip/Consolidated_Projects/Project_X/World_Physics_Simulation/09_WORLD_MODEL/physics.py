# physics.py

class WorldPhysics:
    """
    Defines local interaction rules of the environment.
    Must obey Sandy’s Law but is not Sandy’s Law itself.
    """

    def apply(self, action: dict) -> dict:
        # Placeholder: apply friction, resistance, delays, etc.
        return {"result": action}
