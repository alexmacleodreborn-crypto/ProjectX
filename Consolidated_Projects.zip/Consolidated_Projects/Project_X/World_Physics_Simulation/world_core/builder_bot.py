class BuilderBot:
    """
    Dormant until manager approval.
    Executes plans (placeholder).
    """
    def execute(self, plans, world=None):
        # In stage-1, builder does not mutate the world.
        # Later, it can place bricks/walls etc.
        return