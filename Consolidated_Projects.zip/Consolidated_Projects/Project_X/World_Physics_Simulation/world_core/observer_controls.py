def can_start_day(a7do):
    return a7do.is_awake