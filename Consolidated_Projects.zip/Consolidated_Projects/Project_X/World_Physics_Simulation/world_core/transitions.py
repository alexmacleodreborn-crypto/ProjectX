def birth_sequence(world):
    return ["hospital"]

def journey_home(world):
    return ["hospital", "street", "home"]