# world_core/profiles/__init__.py

# Intentionally minimal to avoid circular imports